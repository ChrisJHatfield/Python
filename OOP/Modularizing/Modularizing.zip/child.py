import parent
print(locals())