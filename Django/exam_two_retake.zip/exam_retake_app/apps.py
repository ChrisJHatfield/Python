from django.apps import AppConfig


class ExamRetakeAppConfig(AppConfig):
    name = 'exam_retake_app'
