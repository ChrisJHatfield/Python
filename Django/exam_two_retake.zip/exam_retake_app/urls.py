from django.urls import path
from . import views

urlpatterns = [
    #Render Page Paths**********************
    path('', views.home),
    path('thoughts', views.thoughts),
    path('thoughts/<int:thought_id>', views.thought_details),
    #User Paths*****************************
    path('register/new-user', views.register),
    path('login/user', views.login),
    path('logout/user', views.logout),
    #Thought Paths**************************
    path('thoughts/create', views.create_thought),
    path('thoughts/delete/<int:thought_id>', views.delete_thought),
    #Like Thought Paths*********************
    path('thoughts/like/<int:thought_id>', views.thought_liked),
    path('thoughts/unlike/<int:thought_id>', views.thought_unliked),
]