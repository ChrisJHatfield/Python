from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User, Thought
import bcrypt

#Render Page Functions***********************
def home(request):
    return render(request, 'home.html')

def thoughts(request):
    if 'uuid' not in request.session:
        return redirect('/')
    user_in_session = request.session['uuid']
    context = {
        'user': User.objects.get(id=user_in_session),
        'thoughts' : Thought.objects.all(),
    }
    print(thoughts)
    return render(request, 'thoughts.html', context)

def thought_details(request, thought_id):
    if 'uuid' not in request.session:
        return redirect('/')
    details = Thought.objects.get(id=thought_id)
    context = {
        'details' : details,
        'user_in_session': User.objects.get(id=request.session['uuid']),
        'users_who_liked' : details.users_who_liked.all(),
    }
    return render(request, 'details.html', context)

#User Functions************************************
def register(request):
    errors = User.objects.register_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)
        return redirect('/')
    else:
        print(request.POST)
        password = request.POST['register_password']
        pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        user = User.objects.create(
            first_name = request.POST['register_first_name'],
            last_name = request.POST['register_last_name'],
            email = request.POST['register_email'],
            password = pw_hash,
        )
    request.session['uuid'] = user.id
    return redirect('/thoughts')

def login(request):
    errors = User.objects.login_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)
    else:
        print(request.POST)
        user = User.objects.get(email=request.POST['login_email'])
        if user:
            logged_user = user
            if bcrypt.checkpw(request.POST['login_password'].encode(), logged_user.password.encode()):
                request.session['uuid'] = logged_user.id
                return redirect('/thoughts')
    return redirect('/')

def logout(request):
    request.session.flush()
    return redirect('/')

#Thought Functions***************************************************
def create_thought(request):
    print(request.POST)
    errors = Thought.objects.thought_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)
    else: 
        user_posted_thought = User.objects.get(id=request.session['uuid'])
        Thought.objects.create(
            thought = request.POST['thought_description'],
            user_thought = user_posted_thought,
        )
    return redirect('/thoughts')

def delete_thought(request, thought_id):
    delete_thought = Thought.objects.get(id=thought_id)
    delete_thought.delete()
    return redirect('/thoughts')

#Liked Thought Functions************************************
def thought_liked(request, thought_id):
    user_liking = User.objects.get(id=request.session['uuid'])
    thought_liked = Thought.objects.get(id=thought_id)
    user_liking.thoughts_liked.add(thought_liked)
    print(f'thought: {thought_id} liked')
    return redirect(f'/thoughts/{thought_id}')

def thought_unliked(request, thought_id):
    user_liking = User.objects.get(id=request.session['uuid'])
    thought_unliked = Thought.objects.get(id=thought_id)
    user_liking.thoughts_liked.remove(thought_unliked)
    print(f'thought: {thought_id} unliked')
    return redirect(f'/thoughts/{thought_id}')