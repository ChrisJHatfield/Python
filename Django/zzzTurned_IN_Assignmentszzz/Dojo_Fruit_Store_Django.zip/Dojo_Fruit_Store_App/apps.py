from django.apps import AppConfig


class DojoFruitStoreAppConfig(AppConfig):
    name = 'Dojo_Fruit_Store_App'
