from django.apps import AppConfig


class GreatNumberGameAppConfig(AppConfig):
    name = 'great_number_game_app'
