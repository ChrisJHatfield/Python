from django.apps import AppConfig


class FirstDjangoAppConfig(AppConfig):
    name = 'First_Django_App'
