console.log("hello world!")

// $(document).ready(function(){
//     console.log("document is loaded");
// });