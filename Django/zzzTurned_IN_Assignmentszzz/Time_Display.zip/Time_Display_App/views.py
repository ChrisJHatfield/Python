from django.shortcuts import render
from time import strftime, localtime

# Create your views here.
def index(request):
    context = {
        "time": strftime("%b %d, %Y %I:%S %p", localtime())
    }
    return render(request, "index.html", context)