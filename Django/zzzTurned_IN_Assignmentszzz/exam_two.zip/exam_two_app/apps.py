from django.apps import AppConfig


class ExamTwoAppConfig(AppConfig):
    name = 'exam_two_app'
