from django.db import models

class Shows(models.Model):
    title = models.CharField(max_length=60)
    network = models.CharField(max_length=60)
    release_date = models.CharField(max_length=60)
    description = models.TextField(default="", max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)