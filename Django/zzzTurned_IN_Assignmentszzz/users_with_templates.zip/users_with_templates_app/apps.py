from django.apps import AppConfig


class UsersWithTemplatesAppConfig(AppConfig):
    name = 'users_with_templates_app'
